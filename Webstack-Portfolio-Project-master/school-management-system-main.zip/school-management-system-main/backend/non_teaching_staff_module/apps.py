from django.apps import AppConfig


class NonTeachingStaffModuleConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "non_teaching_staff_module"
