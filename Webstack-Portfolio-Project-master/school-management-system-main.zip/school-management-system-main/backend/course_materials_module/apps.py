from django.apps import AppConfig


class CourseMaterialsModuleConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "course_materials_module"
