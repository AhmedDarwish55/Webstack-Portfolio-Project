# SmartConnect UI

## How to setup

- git clone repository
- cd frontend
- `npm install` to install all project dependencies
- `npm run dev` to start local development server
