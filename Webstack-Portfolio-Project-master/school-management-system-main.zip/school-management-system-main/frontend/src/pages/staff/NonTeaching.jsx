import Header from '../../components/headers/dashboard/Header';

const NonTeaching = () => {
  //  const { user } = useAuthState();

  return (
    <div className='w-full'>
      <Header />
    </div>
  );
};

export default NonTeaching;
