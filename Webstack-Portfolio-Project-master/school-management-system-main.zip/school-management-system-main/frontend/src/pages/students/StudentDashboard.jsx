import Header from '../../components/headers/dashboard/Header';
// import useAuthState from '../../hooks/useAuth';

const StudentDashboard = () => {
  // const { user } = useAuthState();

  return (
    <div className='w-full'>
      <Header />
    </div>
  );
};

export default StudentDashboard;
