import Header from '../../components/headers/dashboard/Header';

const TeacherDashboard = () => {
  return (
    <div className='w-full'>
      <Header />
    </div>
  );
};

export default TeacherDashboard;
