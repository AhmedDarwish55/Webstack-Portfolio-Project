// convert array of strings to a single string separated by commas
export function arrayToString(arr) {
  return arr.join(', ');
}
